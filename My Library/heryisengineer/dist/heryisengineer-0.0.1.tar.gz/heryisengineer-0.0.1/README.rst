ນີ້ແມ່ນ Package Library Python ອັພໂຫຼດຂຶ້ນ PyPi.org ”
=====================================================

PyPi: https://pypi.org/project/heryisengineer/

ສະບາຍດີ Package ນີ້ແມ່ນສະແດງຂໍ່ມູນກ່ຽວກັບ Hery Engineer
ສາມາດຕິດຕາມຜົນງານໄດ້ໃນ Facebook Page

ວິທີຕິດຕັ້ງ
~~~~~~~~~~~

ເປີດ CMD / Terminal

.. code:: python

   pip install heryisengineer

ວິທີໃຊ້ງານ Package
~~~~~~~~~~~~~~~~~~

-  ເປີດ IDLE ຂຶ້ນມາແລ້ວພິມ…

.. code:: python

   from heryisengineer import HeryIsEngineer

   myname = HeryIsEngineer()
   myname.show_name()
   myname.show_facebook_page()
   myname.about()
   myname.show_art()

ພັດທະນາໂດຍ : Hery Engineer

FB : https://www.facebook.com/herytwenty.phonsavad GitHub :
https://github.com/Thitphavanh
